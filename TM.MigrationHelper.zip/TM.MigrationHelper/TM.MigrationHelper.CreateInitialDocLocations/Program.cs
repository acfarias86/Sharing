﻿using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace TM.MigrationHelper.CreateInitialDocLocations
{
    internal class Program
    {
        private static ServiceClient serviceClient = null;
        public static ServiceClient ServiceClient
        {
            get
            {
                if (serviceClient == null)
                {
                    Console.WriteLine("Select the environment:");
                    Console.WriteLine("[1] D365-PANDIFDD-DEV  - https://pandifdddev.crm11.dynamics.com/");
                    Console.WriteLine("[2] D365-PANDIFDD-TEST - https://pandifddtest.crm11.dynamics.com/");
                    Console.WriteLine("[3] D365-PANDIFDD-UAT  - https://pandifdduat.crm11.dynamics.com/");
                    Console.WriteLine("[4] D365-PANDIFDD-PRD  - https://pandifdd.crm11.dynamics.com/");
                    Console.Write("Enter the number of the environment: ");
                    string choice = Console.ReadLine();

                    string url;
                    switch (choice)
                    {
                        case "1": url = "https://pandifdddev.crm11.dynamics.com/"; break;
                        case "2": url = "https://pandifddtest.crm11.dynamics.com/"; break;
                        case "3": url = "https://pandifdduat.crm11.dynamics.com/"; break;
                        case "4": url = "https://pandifdd.crm11.dynamics.com/"; break;
                        default: throw new Exception("Invalid choice.");
                    }

                    Console.Write("Enter Client ID: ");
                    string clientId = Console.ReadLine();
                    Console.Write("Enter Client Secret: ");
                    string clientSecret = Console.ReadLine();

                    serviceClient = new ServiceClient($"AuthType=ClientSecret;Url={url};ClientId={clientId};ClientSecret={clientSecret}");
                }
                return serviceClient;
            }
        }

        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.Write("Enter the table schema name: ");
                    string entityName = Console.ReadLine();
                    Console.WriteLine($"Processing records for entity: {entityName}");

                    Tuple<string, string> entityPrimaryFields = GetEntityPrimaryFieldsBy(entityName);
                    List<Entity> entitiesToProcess = ListRecordsWithoutDocLocationBy(entityName, entityPrimaryFields);

                    Console.WriteLine($"Found {entitiesToProcess.Count} records without a Document Location.");
                    int processed = 0;

                    foreach (Entity entityToProcess in entitiesToProcess)
                    {
                        CreateSharePointStructure(entityName, entityToProcess.Id);
                        processed++;
                        Console.WriteLine($"[{processed}/{entitiesToProcess.Count}] Processed record ID: {entityToProcess.Id}");
                    }

                    Console.WriteLine("Operation completed successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }

                Console.Write("Do you want to process another table? (yes/no): ");
                string response = Console.ReadLine().Trim().ToLower();
                if (response != "yes")
                    break;
            }
        }

        private static EntityReference CreateSharePointStructure(string targetLogicalName, Guid targetId)
        {
            try
            {
                Console.WriteLine($"Creating SharePoint structure for record ID: {targetId}");
                OrganizationRequest request = new OrganizationRequest("cs_CreateSharePointStructure");
                request["TargetId"] = targetId.ToString();
                request["TargetLogicalName"] = targetLogicalName;

                OrganizationResponse response = ServiceClient.Execute(request);
                Console.WriteLine($"SharePoint structure created for record ID: {targetId}");

                return response["Location"] as EntityReference;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating SharePoint structure: {ex.Message}");
                return null;
            }
        }

        private static List<Entity> ListRecordsWithoutDocLocationBy(string entityLogicalName, Tuple<string, string> entityPrimeryFields)
        {
            try
            {
                Console.WriteLine("Retrieving records without a Document Location...");
                QueryExpression query = new QueryExpression(entityLogicalName) { Distinct = true, NoLock = true };
                query.ColumnSet.AddColumns(entityPrimeryFields.Item1, entityPrimeryFields.Item2);
                query.AddLink("sharepointdocumentlocation", entityPrimeryFields.Item1, "regardingobjectid", JoinOperator.NotAny);

                List<Entity> results = ServiceClient.RetrieveMultiple(query)?.Entities?.ToList();
                Console.WriteLine("Records retrieved successfully.");
                return results;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving records: {ex.Message}");
                return new List<Entity>();
            }
        }

        private static Tuple<string, string> GetEntityPrimaryFieldsBy(string entityName)
        {
            try
            {
                Console.WriteLine($"Retrieving primary fields for entity: {entityName}");
                RetrieveEntityRequest retrieveEntityRequest = new RetrieveEntityRequest
                {
                    EntityFilters = EntityFilters.Entity,
                    LogicalName = entityName
                };
                RetrieveEntityResponse retrieveEntityResponse = (RetrieveEntityResponse)ServiceClient.Execute(retrieveEntityRequest);

                string primaryKey = retrieveEntityResponse.EntityMetadata.PrimaryIdAttribute;
                string primaryName = retrieveEntityResponse.EntityMetadata.PrimaryNameAttribute;

                Console.WriteLine("Primary fields retrieved successfully.");
                return new Tuple<string, string>(primaryKey, primaryName);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving entity primary fields: {ex.Message}");
                return new Tuple<string, string>(string.Empty, string.Empty);
            }
        }
    }
}